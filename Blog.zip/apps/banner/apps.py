from django.apps import AppConfig


class BannerConfig(AppConfig):
    name = 'apps.banner'
