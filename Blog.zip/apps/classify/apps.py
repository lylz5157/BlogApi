from django.apps import AppConfig


class ClassifyConfig(AppConfig):
    name = 'apps.classify'
